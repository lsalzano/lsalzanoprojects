function integraleLas=Las2dmono(p,exp1,exp2)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Function per calcolare con la formula di Lasserre gli integrali della
%base monomiale sul simplesso 2-dimensionale, ossia il triangolo di
%vertici [0 0], [1 0], [0 1].

%Area triangolo. 
vol=.5;

%Calcolo del punto csi.
gradoomog=exp1+exp2;
vett=[];
for r=1:gradoomog
    sommaparz=2+r;
    vett=[vett sommaparz];
end
pr=prod(vett,'all');
csi=ones(1,2)*(pr)^(-1/gradoomog);

%Calcolo del polinomio di Bombieri associato a quello in input.
coeff=factorial(exp1)*factorial(exp2);
h=@(x,y) coeff+0*x^0+0*y^0;
bombp=@(x,y) p(x,y)*h(x,y);

%Calcolo dell'integrale.
integraleLas=vol*feval(bombp,csi(1),csi(2));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
