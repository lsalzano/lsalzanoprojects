function integraleLas=Las3dmono(p,exp1,exp2,exp3)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Function per calcolare con la formula di Lasserre gli integrali della
%base monomiale sul simplesso 3-dimensionale, ossia il tetraedro di
%vertici [0 0 0], [1 0 0], [0 1 0], [0 0 1].

%Volume tetraedro. 
vol=1/6;

%Calcolo del punto csi.
gradoomog=exp1+exp2+exp3;
vett=[];
for r=1:gradoomog
    sommaparz=3+r;
    vett=[vett sommaparz];
end
pr=prod(vett,'all');
csi=ones(1,3)*(pr)^(-1/gradoomog);

%Calcolo del polinomio di Bombieri associato a quello in input.
coeff=factorial(exp1)*factorial(exp2)*factorial(exp3);
h=@(x,y,z) coeff+0*x^0+0*y^0+0*z^0;
bombp=@(x,y,z) p(x,y,z)*h(x,y,z);

%Calcolo dell'integrale.
integraleLas=vol*feval(bombp,csi(1),csi(2),csi(3))
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
