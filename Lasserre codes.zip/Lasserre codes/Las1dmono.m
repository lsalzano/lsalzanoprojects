function integraleLas1d=Las1dmono(p,exp)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Function per calcolare con la formula di Lasserre gli integrali della
%base monomiale sul simplesso 1-dimensionale, ossia il segmento [0,1].

%Area segmento. 
vol=1;

%Calcolo del punto csi.
gradoomog=exp;
vett=[];
for r=1:gradoomog
    sommaparz=1+r;
    vett=[vett sommaparz];
end
pr=prod(vett,'all');
csi=(pr)^(-1/gradoomog);

%Calcolo del polinomio di Bombieri associato a quello in input.
coeff=factorial(exp);
h=@(x) coeff+0*x^0;
bombp=@(x) p(x)*h(x);

%Calcolo dell'integrale.
integraleLas1d=vol*feval(bombp,csi);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
