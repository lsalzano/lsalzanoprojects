﻿using System;
using System.Linq;
namespace FinalProjectSalzano
{
    public class Application
    {
        //field
        private gameinteresting partite;

        //costructor
        public Application(gameinteresting partite)
        {

            this.partite = partite;
        }




        public double model(string inputmoves, string parola)
        {
            int count = 0;
            int vincitew = 0;
            int vinciteb = 0;
            int vincited = 0;


            //The moves in input are analyzed and I count how much time it appairs. N.B. if the input is only "e4" I find all the games starting with this move, so
            //I need to use a partial count, otherwise the software could find only the games with one move "e4" and no more moves.

            for (int i = 1; i < partite.rated.Length; i++)
            {
                int partialcount = 0;
                for (int j = 0; j < inputmoves.Length; j++)
                {

                    if (inputmoves[j] == partite.moves[i][j])
                    {

                        partialcount += 1;

                    }
                    else
                    {

                        partialcount += 0;
                    }


                }


                if (partialcount == inputmoves.Length)
                {
                    count += 1;

                    if (partite.winnercol[i] == "white")
                    {
                        vincitew += 1;

                    }
                    else if (partite.winnercol[i] == "black")
                    {
                        vinciteb += 1;

                    }
                    else
                    {

                        vincited += 1;
                    }


                }
                else
                {
                    count += 0;
                }



            }

            //if the second input is "info", the software give some info about the opening, like the name and the percentage of winning for black, white or draw, otherwise the code jumps this part.

            if (parola == "info")
            {
                if (count == 0)
                {
                    Console.WriteLine("No matches found with this opening.");

                }
                else
                {
                    double percentagewhite = vincitew * 100 / count;
                    double percentageblack = vinciteb * 100 / count;

                    double percentagedraw = 100 - percentagewhite - percentageblack;

                    if ((percentagewhite > percentageblack) && (percentagewhite > percentagedraw))
                    {

                        string advantage = " the white";
                        Console.Write("I find in the database {0} games with this opening moves. Globally the white player wins {1}% of times, the black player wins {2}% of times, and the draw happens {3}% of times.\n This opening advatages{4}.  ", count, percentagewhite, percentageblack, percentagedraw, advantage);



                    }
                    else if ((percentageblack > percentagewhite) && (percentageblack > percentagedraw))
                    {

                        string advantage = " the black";
                        Console.Write("I find in the database {0} games with this opening moves. Globally the white player wins {1}% of times, the black player wins {2}% of times, and the draw happens {3}% of times.\n This opening advatages{4}.  ", count, percentagewhite, percentageblack, percentagedraw, advantage);


                    }
                    else if ((percentageblack == percentagewhite))
                    {

                        string advantage = " the black";
                        Console.Write("I find in the database {0} games with this opening moves. Globally the white player wins {1}% of times, the black player wins {2}% of times, and the draw happens {3}% of times.\n This opening is balanced.  ", count, percentagewhite, percentageblack, percentagedraw);


                    }
                    else
                    {
                        string advantage = " the draw";
                        Console.Write("I find in the database {0} games with this opening moves. Globally the white player wins {1}% of times, the black player wins {2}% of times, and the draw happens {3}% of times.\nThis opening advatages{4}.  ", count, percentagewhite, percentageblack, percentagedraw, advantage);

                    }


                }

                //A little database of openings, as a multidimensional array
                string[,] openings = new string[,] { { "e4 e5 Nf3 Nc6 Bb5", "Ruy Lopez" }, { "e4 e5 Nf3 Nc6 d4", "Scotch Game" },
            {"e4 e5 Nf3 Nc6 Bc4","Italian Game" },{"e4 e5 Nf3 Nc6 Nc3 Nf6","Four Knights Game" },{"e4 e5 Nf3 Nf6","Petrov's Defense" },
            {"e4 e5 Nf3 d6","Philidor Defense" },{"e4 e5 Nc3","Vienna Game" },{"e4 e5 Bc4","Bishop's Opening" },{"e4 e5 f4","King's Gambit" },
            {"e4 e5 d4 exd4 Qxd4","Center Game" },{"e4 e5 d4 exd4 c3","Danish Gambit" },{"e4 c5","Sicilian Defense" },{"e4 e6"," French Defense" },
            {"e4 c6","Caro–Kann Defense" },
            {"e4 d5","Scandinavian Defense" },{"e4 d6 d4 Nf6 Nc3 g6","Pirc Defense" },{"e4 Nf6","Alekhine's Defense" },{"e4 g6","Modern Defense" },
            {"d4 d5 c4","Queen's Gambit" },{"d4 d5 c4 c6","Slav Defense" },{"d4 d5 Nf3 Nf6 e3","Colle System" },{"d4 Nf6 c4 c5 d5 e6","Modern Benoni" },
            {"d4 Nf6 c4 c5 d5 b5","Benko Gambit" },{"d4 Nf6 c4 e6 Nc3 Bb4","Nimzo-Indian Defense" },{"d4 Nf6 c4 e6 Nf3 b6","Queen's Indian Defense" },
            {"d4 Nf6 c4 e6 g3","Catalan Opening" },
            {"d4 Nf6 c4 g6 Nc3 d5"," Grünfeld Defense" },{"d4 Nf6 c4 g6 Nc3 Bg7","King's Indian Defense" },{"d4 c5","Benoni Defense" },{"d4 f5","Dutch Defense" },
            {"b3","Larsen's Opening" },{"b4","Sokolsky Opening" },{"c4","English Opening" },{"Nf3","Zukertort Opening" },{"f4","Bird's Opening" },
            {"g3","Benko Opening" },{"g4","Grob's Attack" },{"e4 g5","Borg Defense" }, {"d4 g6","Modern Defense" } };



                for (int i = 0; i < openings.GetLength(0); i++)
                {
                    int partialcount = 0;
                    for (int u = 0; u < openings[i, 0].Length; u++)
                    {

                        if (openings[i, 0].Length <= inputmoves.Length)
                        {

                            if (openings[i, 0][u] == inputmoves[u])
                            {
                                partialcount += 1;
                            }
                            else
                            {
                                partialcount += 0;

                            }
                        }

                    }

                    if (partialcount == openings[i, 0].Length)
                    {
                        Console.WriteLine("This opening is called {0}.", openings[i, 1]);


                    }




                }
            }
            //I evaluate the percentage of winning of black.
            if (count == 0)
            {
                return -1;
            }
            else
            {

                double p = vinciteb * 100 / count;

                return p;
            }

        }


        //The following method selects which is the most winning reply to the first move, prints the results and return a multidimensional array with moves and best reply.

        public static string[,] Printer(string[] firstmoves, string[] secondmoves, double[,] perc, string outp)
        {



            //I initialize 20 arrays

            double[] v0 = new double[secondmoves.Length];
            double[] v1 = new double[secondmoves.Length];
            double[] v2 = new double[secondmoves.Length];
            double[] v3 = new double[secondmoves.Length];
            double[] v4 = new double[secondmoves.Length];
            double[] v5 = new double[secondmoves.Length];
            double[] v6 = new double[secondmoves.Length];
            double[] v7 = new double[secondmoves.Length];
            double[] v8 = new double[secondmoves.Length];
            double[] v9 = new double[secondmoves.Length];
            double[] v10 = new double[secondmoves.Length];
            double[] v11 = new double[secondmoves.Length];
            double[] v12 = new double[secondmoves.Length];
            double[] v13 = new double[secondmoves.Length];
            double[] v14 = new double[secondmoves.Length];
            double[] v15 = new double[secondmoves.Length];
            double[] v16 = new double[secondmoves.Length];
            double[] v17 = new double[secondmoves.Length];
            double[] v18 = new double[secondmoves.Length];
            double[] v19 = new double[secondmoves.Length];

            //I populate the arrays with the percentages of winning of black. The first array is made by all the the percentages of winning for black replying
            // a3, the second replying a4 and so on. For example the entrance (0) of v0 is the percentage of winning for the black replying a6 to a3.

            for (int i = 0; i < secondmoves.Length; i++)
            {

                v0[i] = perc[0, i];
                v1[i] = perc[1, i];
                v2[i] = perc[2, i];
                v3[i] = perc[3, i];
                v4[i] = perc[4, i];
                v5[i] = perc[5, i];
                v6[i] = perc[6, i];
                v7[i] = perc[7, i];
                v8[i] = perc[8, i];
                v9[i] = perc[9, i];
                v10[i] = perc[10, i];
                v11[i] = perc[11, i];
                v12[i] = perc[12, i];
                v13[i] = perc[13, i];
                v14[i] = perc[14, i];
                v15[i] = perc[15, i];
                v16[i] = perc[16, i];
                v17[i] = perc[17, i];
                v18[i] = perc[18, i];
                v19[i] = perc[19, i];
            }

            //For each array I find the max and the relative index, to reconduct myself to which reply is connected with this percentage.

            double maxValue0 = v0.Max();
            int maxIndex0 = v0.ToList().IndexOf(maxValue0);
            double maxValue1 = v1.Max();
            int maxIndex1 = v1.ToList().IndexOf(maxValue1);
            double maxValue2 = v2.Max();
            int maxIndex2 = v2.ToList().IndexOf(maxValue2);
            double maxValue3 = v3.Max();
            int maxIndex3 = v3.ToList().IndexOf(maxValue3);
            double maxValue4 = v4.Max();
            int maxIndex4 = v4.ToList().IndexOf(maxValue4);
            double maxValue5 = v5.Max();
            int maxIndex5 = v5.ToList().IndexOf(maxValue5);
            double maxValue6 = v6.Max();
            int maxIndex6 = v6.ToList().IndexOf(maxValue6);
            double maxValue7 = v7.Max();
            int maxIndex7 = v7.ToList().IndexOf(maxValue7);
            double maxValue8 = v8.Max();
            int maxIndex8 = v8.ToList().IndexOf(maxValue8);
            double maxValue9 = v9.Max();
            int maxIndex9 = v9.ToList().IndexOf(maxValue9);
            double maxValue10 = v10.Max();
            int maxIndex10 = v10.ToList().IndexOf(maxValue10);
            double maxValue11 = v11.Max();
            int maxIndex11 = v11.ToList().IndexOf(maxValue11);
            double maxValue12 = v12.Max();
            int maxIndex12 = v12.ToList().IndexOf(maxValue12);
            double maxValue13 = v13.Max();
            int maxIndex13 = v13.ToList().IndexOf(maxValue13);
            double maxValue14 = v14.Max();
            int maxIndex14 = v14.ToList().IndexOf(maxValue14);
            double maxValue15 = v15.Max();
            int maxIndex15 = v15.ToList().IndexOf(maxValue15);
            double maxValue16 = v16.Max();
            int maxIndex16 = v16.ToList().IndexOf(maxValue16);
            double maxValue17 = v17.Max();
            int maxIndex17 = v17.ToList().IndexOf(maxValue17);
            double maxValue18 = v18.Max();
            int maxIndex18 = v18.ToList().IndexOf(maxValue18);
            double maxValue19 = v19.Max();
            int maxIndex19 = v19.ToList().IndexOf(maxValue19);

            //I print the results

            if (outp == "output")
            {

                Console.WriteLine("The best move after {0} is {1}", firstmoves[0], secondmoves[maxIndex0]);
                Console.WriteLine("The best move after {0} is {1}", firstmoves[1], secondmoves[maxIndex1]);
                Console.WriteLine("The best move after {0} is {1}", firstmoves[2], secondmoves[maxIndex2]);
                Console.WriteLine("The best move after {0} is {1}", firstmoves[3], secondmoves[maxIndex3]);
                Console.WriteLine("The best move after {0} is {1}", firstmoves[4], secondmoves[maxIndex4]);
                Console.WriteLine("The best move after {0} is {1}", firstmoves[5], secondmoves[maxIndex5]);
                Console.WriteLine("The best move after {0} is {1}", firstmoves[6], secondmoves[maxIndex6]);
                Console.WriteLine("The best move after {0} is {1}", firstmoves[7], secondmoves[maxIndex7]);
                Console.WriteLine("The best move after {0} is {1}", firstmoves[8], secondmoves[maxIndex8]);
                Console.WriteLine("The best move after {0} is {1}", firstmoves[9], secondmoves[maxIndex9]);
                Console.WriteLine("The best move after {0} is {1}", firstmoves[10], secondmoves[maxIndex10]);
                Console.WriteLine("The best move after {0} is {1}", firstmoves[11], secondmoves[maxIndex11]);
                Console.WriteLine("The best move after {0} is {1}", firstmoves[12], secondmoves[maxIndex12]);
                Console.WriteLine("The best move after {0} is {1}", firstmoves[13], secondmoves[maxIndex13]);
                Console.WriteLine("The best move after {0} is {1}", firstmoves[14], secondmoves[maxIndex14]);
                Console.WriteLine("The best move after {0} is {1}", firstmoves[15], secondmoves[maxIndex15]);
                Console.WriteLine("The best move after {0} is {1}", firstmoves[16], secondmoves[maxIndex16]);
                Console.WriteLine("The best move after {0} is {1}", firstmoves[17], secondmoves[maxIndex17]);
                Console.WriteLine("The best move after {0} is {1}", firstmoves[18], secondmoves[maxIndex18]);
                Console.WriteLine("The best move after {0} is {1}", firstmoves[19], secondmoves[maxIndex19]);

            }

            string[,] results = new string[,] { {firstmoves[0], secondmoves[maxIndex0]}, { firstmoves[1], secondmoves[maxIndex1] }, { firstmoves[2], secondmoves[maxIndex2] },
            {firstmoves[3], secondmoves[maxIndex3]},{firstmoves[4], secondmoves[maxIndex4]},{firstmoves[5], secondmoves[maxIndex5]},{firstmoves[6], secondmoves[maxIndex6]},
            {firstmoves[7], secondmoves[maxIndex7]},{firstmoves[8], secondmoves[maxIndex8]},{firstmoves[9], secondmoves[maxIndex9]},{firstmoves[10], secondmoves[maxIndex10]},
            {firstmoves[11], secondmoves[maxIndex11]},{firstmoves[12], secondmoves[maxIndex12]},{firstmoves[13], secondmoves[maxIndex13]},{firstmoves[14], secondmoves[maxIndex14]},
            {firstmoves[15], secondmoves[maxIndex15]},{firstmoves[16], secondmoves[maxIndex16]},{firstmoves[17], secondmoves[maxIndex17]},{firstmoves[18], secondmoves[maxIndex18]},{firstmoves[19], secondmoves[maxIndex19]}};
            return results;



        }




    }
}