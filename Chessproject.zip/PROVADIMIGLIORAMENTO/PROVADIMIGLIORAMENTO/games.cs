﻿
namespace FinalProjectSalzano
{
    //This class is a container for all the games
    public class games
    {


        public string[] rated;
        public string[] winnercol;
        public string[] moves;



        //costructor

        public games(string[] rated, string[] winnercol, string[] moves)

        {
            this.rated = rated;
            this.winnercol = winnercol;
            this.moves = moves;
            
        }


        


    }


    //subclass of games, in which I will import the games satisfiesing some criteria.

    public class gameinteresting : games
    {



        public gameinteresting(string[] rated, string[] winnercol,  string[] moves) : base(rated, winnercol, moves)


        {



        }
    }

}
