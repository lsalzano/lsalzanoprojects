﻿using System;
using System.IO;


namespace FinalProjectSalzano
{
    class MainClass
    {
        public static void Main(string[] args)
        {

            //------------------------------First selection usung the method SaveFirstSelection of the class IOUtil-------------------------
            string pathgames = "/Users/leonardosalzano/Projects/PROVADIMIGLIORAMENTO/games.csv";
            int totpartite = File.ReadAllLines(pathgames).Length;
            string pathfirst = "/Users/leonardosalzano/Projects/PROVADIMIGLIORAMENTO/SaveFirstSelection.csv";
            File.Create(pathfirst).Dispose();
            IOUtil.SaveFirstSelection(pathgames, pathfirst, totpartite);

            ////// -------------------------------------------------Shuffling---------------------------------------------------------------------                                                     


            int partitebuone = File.ReadAllLines(pathfirst).Length;
            //////I create the array and I popule it 
            int[] arr = new int[partitebuone];
            for (int i = 1; i < partitebuone; i++)
            {
                arr[i] = i;
            };

            int[] indici = IOUtil.RandomTrainingandTest(arr);
            string savesecond = "/Users/leonardosalzano/Projects/PROVADIMIGLIORAMENTO/SaveSecondSelection.csv";
            File.Create(savesecond).Dispose();
            IOUtil.SaveOutput(pathfirst, savesecond, indici);


            //////-------------------------------------------------Training and Test set------------------------------------------------------------------
            int totale = File.ReadAllLines(savesecond).Length;
            int percetage80 = totale * 80 / 100;
            int[] newarr1 = new int[percetage80];
            int percetage20 = totale - percetage80;
            int[] newarr2 = new int[percetage20];
            for (int i = 0; i < percetage80; i++)
            {
                newarr1[i] = i;
            }

            for (int i = 0; i < newarr2.Length; i++)
            {

                newarr2[i] = i + percetage80;


            }
            string TRAIN = "/Users/leonardosalzano/Projects/PROVADIMIGLIORAMENTO/TRAINING.csv";
            File.Create(TRAIN).Dispose();
            IOUtil.SaveOutput(savesecond, TRAIN, newarr1);
            string TEST = "/Users/leonardosalzano/Projects/PROVADIMIGLIORAMENTO/TEST.csv";
            File.Create(TEST).Dispose();
            IOUtil.SaveOutput(savesecond, TEST, newarr2);



            //----------------------------------------------Initializing training set----------------------------------------------------------------------
            Console.WriteLine("About training set");
            string[] rated = new string[percetage80];
            string[] winnercol = new string[percetage80];
            string[] moves = new string[percetage80];

            for (int i = 1; i < percetage80; i++)
            {
                rated[i] = IOUtil.ParseLine(TRAIN, i, 0)[1];
                winnercol[i] = IOUtil.ParseLine(TRAIN, i, 0)[6];
                moves[i] = IOUtil.ParseLine(TRAIN, i, 0)[12];
            }

            gameinteresting traininggames = new gameinteresting(rated, winnercol, moves);

            Application primotest = new Application(traininggames);




            string[] firstmoves = new string[] { "a3", "a4", "b3", "b4", "c3", "c4", "d3", "d4", "e3", "e4", "f3", "f4", "g3", "g4", "h3", "h4", "Na3", "Nc3", "Nf3", "Nh3" };
            string[] secondmoves = new string[] { "a6", "a5", "b6", "b5", "c6", "c5", "d6", "d5", "e6", "e5", "f6", "f5", "g6", "g5", "h6", "h5", "Na6", "Nc6", "Nf6", "Nh6" };

            //I populate a matrix with the percentages of winning of black for all the possible couple of moves.
            double[,] perc = new double[firstmoves.Length, secondmoves.Length];
            for (int i = 0; i < firstmoves.Length; i++)
            {
                for (int j = 0; j < firstmoves.Length; j++)
                {

                    perc[i, j] = primotest.model(firstmoves[i] + " " + secondmoves[j], "a");

                }
            }
            //The following method analyzes each row of the matrix and prints which is the most winning reply for each initial move.
            Application.Printer(firstmoves, secondmoves, perc, "output");

            //----------------------------------------------Initializing test set----------------------------------------------------------------------

            Console.WriteLine("About test set");
            string[] rated1 = new string[percetage20];
            string[] winnercol1 = new string[percetage20];
            string[] moves1 = new string[percetage20];

            for (int i = 1; i < percetage20; i++)
            {
                rated1[i] = IOUtil.ParseLine(TEST, i, 0)[1];
                winnercol1[i] = IOUtil.ParseLine(TEST, i, 0)[6];
                moves1[i] = IOUtil.ParseLine(TEST, i, 0)[12];



            }

            gameinteresting testgames = new gameinteresting(rated1, winnercol1, moves1);

            Application secondotest = new Application(testgames);




            double[,] perc1 = new double[firstmoves.Length, secondmoves.Length];
            for (int i = 0; i < firstmoves.Length; i++)
            {
                for (int j = 0; j < firstmoves.Length; j++)
                {

                    perc1[i, j] = secondotest.model(firstmoves[i] + " " + secondmoves[j], "a");

                }
            }




            //primotest.model("d4 d5 c4","info");
            // secondotest.model("e4","info");



            //-----------------------------------------------Validation----------------------------------------------------------
            int countvolt = 0;
            int countwin = 0;
            for (int i = 1; i < percetage20; i++)
            {
                for (int u = 0; u < firstmoves.Length; u++)
                {


                    if ((moves1[i][0] == Application.Printer(firstmoves, secondmoves, perc1, "")[u, 0][0]) && (moves1[i][1] == Application.Printer(firstmoves, secondmoves, perc1, "")[u, 0][1]))
                    {

                        if ((moves1[i][3] == Application.Printer(firstmoves, secondmoves, perc1, "")[u, 1][0]) && (moves1[i][4] == Application.Printer(firstmoves, secondmoves, perc1, "")[u, 1][1]))
                        {

                            countvolt += 1;

                            if (winnercol1[i] == "black")
                            {

                                countwin += 1;
                            }
                        }

                    }

                }

            }

            double rat = (Convert.ToDouble(countwin) / Convert.ToDouble(countvolt)) * 100;

            Console.WriteLine("\nIn the test set the best move was played {0} times and in this the black wins {1} times,i.e the {2}% of times.", countvolt, countwin, rat);

        }
    }
}
