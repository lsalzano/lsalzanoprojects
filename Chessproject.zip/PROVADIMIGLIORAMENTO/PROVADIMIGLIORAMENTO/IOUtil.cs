﻿using System;
using System.IO;
using System.Linq;





namespace FinalProjectSalzano
{
    public class IOUtil
    {

        public IOUtil()

        {

        }

        //Separate all the rows of a csv file in an array
        private static string[] LoadData(string path)
        {

            StreamReader sr = new StreamReader(path);
            string strResult = sr.ReadToEnd();
            string[] result = strResult.Split(new string[] { Environment.NewLine }, StringSplitOptions.None);
            return result;




        }
        //Get the (i,j) feature, splitting each row of the csv file
        public static string[] ParseLine(string path, int i, int j)
        {
            string[] g1 = LoadData(path)[i].Split(',').ToArray();
            return g1;
        }


        //Give an array of int as input and the output is the random shuffled array.
        public static int[] RandomTrainingandTest(int[] arr)
        {


            Random random = new Random();
            arr = arr.OrderBy(x => random.Next()).ToArray();
            return arr;

        }











        //SaveOutput saves in the second input (a csv file) the games.
        public static void SaveOutput(string path, string pathwrite, int[] arr)
        {

            foreach (int i in arr)

            {

                for (int j = 0; j < 16; j++)
                {
                    if (j != 15)
                    {
                        string wText = ParseLine(path, i, j)[j] + ",";
                        File.AppendAllText(pathwrite, wText);
                    }
                    else
                    {
                        string wText = ParseLine(path, i, j)[j];
                        File.AppendAllText(pathwrite, wText);
                    }
                }
                string pausa = "\n";
                File.AppendAllText(pathwrite, pausa);
            }


        }



        //The following method imports from the first input to the second the games with respect the condition of being rated and the difference of elo is smaller the 20.
        public static void SaveFirstSelection(string path, string pathwrite, int totpartite)
        {

            for (int i = 1; i < totpartite; i++)
            {
                string[] iesimariga = ParseLine(path, i, 0);
                int numterza = Int32.Parse(iesimariga[9]);
                int numquarta = Int32.Parse(iesimariga[11]);


                int maggiore;
                int minore;
                if (numterza > numquarta)
                {
                    maggiore = numterza;
                    minore = numquarta;
                }
                else
                {

                    maggiore = numquarta;
                    minore = numterza;

                }

                if ((iesimariga[1] == "TRUE") && (maggiore - minore < 20))
                {
                    for (int j = 0; j < 16; j++)
                    {
                        if (j != 15)
                        {
                            string wText = ParseLine(path, i, j)[j] + ",";
                            File.AppendAllText(pathwrite, wText);
                        }
                        else
                        {
                            string wText = ParseLine(path, i, j)[j];
                            File.AppendAllText(pathwrite, wText);
                        }
                    }
                    string pausa = "\n";
                    File.AppendAllText(pathwrite, pausa);

                }
            }



        }





    }
}